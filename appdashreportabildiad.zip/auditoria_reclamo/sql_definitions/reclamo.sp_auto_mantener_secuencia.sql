/* ============================================================================
   SP 3.e reclamo.sp_auto_mantener_secuencia

   Orquestador. Es lo que llama el boton del dashboard: el usuario no corre
   EXEC en la base de datos. Primero rellena secuencias huerfanas (modulos
   CONGELADOS de antes de esta automatizacion que nunca llegaron a tener
   fila en secuencia_rotopala), despues cierra y avanza (libera cupo),
   despues congela lo nuevo y precongela lo que viene (y abre lo que ya
   tiene movimiento si quedo cupo). Deja todo en reclamo.log_automatizacion
   y devuelve esa bitacora, ordenada con las alertas primero.

   Backfill de secuencia (agregado 2026-07-30): reclamo.sp_definir_secuencia
   ya se llamaba automaticamente para cada modulo recien congelado (dentro
   de sp_auto_congelar_modulos_nuevos), pero eso no alcanza a los modulos
   que quedaron CONGELADOS antes de que existiera esta automatizacion --
   confirmado en los modulos 125 a 140 de rotopala 2 / campaña 8, todos
   congelados en bloque el 2026-07-29 sin pasar por el flujo automatico, y
   por lo tanto sin fila en secuencia_rotopala. Sin este backfill, cuando el
   modulo 124 se cerraba por avance de secuencia, sp_auto_cerrar_y_avanzar_
   secuencia no encontraba un modulo 125 al cual abrir (porque no existia
   como PENDIENTE) y quedaba en ALERTA_FIN_DE_CAMPANA con un mensaje
   enganoso ("no hay mas modulos congelados"), cuando en realidad si los
   habia, solo que nunca se habian secuenciado. sp_definir_secuencia es
   idempotente: solo agrega los modulos que faltan, nunca reordena ni borra
   los que ya estan.
   ============================================================================ */
CREATE   PROCEDURE [reclamo].[sp_auto_mantener_secuencia]
(
    @VentanaDias int = 90,
    @Siguientes  int = 5
)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    INSERT INTO [reclamo].[log_ejecucion] (procedimiento, estado)
    VALUES ('reclamo.sp_auto_mantener_secuencia', 'EN_CURSO');
    DECLARE @EjecucionId int = SCOPE_IDENTITY();

    BEGIN TRY
        IF EXISTS
        (
            SELECT 1
            FROM [reclamo].[modulo_congelado] mc
            WHERE mc.estado = 'CONGELADO'
              AND NOT EXISTS
              (
                  SELECT 1 FROM [reclamo].[secuencia_rotopala] s
                  WHERE s.[campaña_id] = mc.[campaña_id] AND s.modulo_id = mc.modulo_id
              )
        )
        BEGIN
            DECLARE @CampDef int, @PadDef int;
            DECLARE campañas_def CURSOR LOCAL FAST_FORWARD FOR
                SELECT DISTINCT mc.[campaña_id], mc.pad_id
                FROM [reclamo].[modulo_congelado] mc
                WHERE mc.estado = 'CONGELADO'
                  AND NOT EXISTS
                  (
                      SELECT 1 FROM [reclamo].[secuencia_rotopala] s
                      WHERE s.[campaña_id] = mc.[campaña_id] AND s.modulo_id = mc.modulo_id
                  );
            OPEN campañas_def;
            FETCH NEXT FROM campañas_def INTO @CampDef, @PadDef;
            WHILE @@FETCH_STATUS = 0
            BEGIN
                BEGIN TRY
                    EXEC [reclamo].[sp_definir_secuencia]
                         @CampañaId = @CampDef, @PadId = @PadDef;

                    INSERT INTO [reclamo].[log_automatizacion]
                        (ejecucion_id, accion, pad_id, [campaña_id], detalle)
                    VALUES
                        (@EjecucionId, 'SECUENCIADO_AUTOMATICO', @PadDef, @CampDef,
                         N'Backfill: se agregaron a secuencia_rotopala los modulos '
                            + N'CONGELADOS de esta campana/pad que no tenian fila.');
                END TRY
                BEGIN CATCH
                    INSERT INTO [reclamo].[log_automatizacion]
                        (ejecucion_id, accion, pad_id, [campaña_id], detalle)
                    VALUES
                        (@EjecucionId, 'ALERTA_SIN_BASE', @PadDef, @CampDef,
                         N'Error en backfill de secuencia: ' + ERROR_MESSAGE());
                END CATCH;
                FETCH NEXT FROM campañas_def INTO @CampDef, @PadDef;
            END;
            CLOSE campañas_def;
            DEALLOCATE campañas_def;
        END;

        EXEC [reclamo].[sp_auto_cerrar_y_avanzar_secuencia] @EjecucionId = @EjecucionId;

        EXEC [reclamo].[sp_auto_congelar_modulos_nuevos]
             @VentanaDias = @VentanaDias, @Siguientes = @Siguientes, @EjecucionId = @EjecucionId;

        /* -------------------------------------------------------------
           Relleno de cupo huerfano (agregado 2026-07-30, corregido el
           mismo dia): si una rotopala/campaña queda con CERO modulos
           ABIERTO pero SI tiene al menos un CERRADO (caso del modulo 124:
           se cerro en una corrida anterior a que existiera el backfill de
           secuencia de mas arriba, asi que su sucesor nunca se abrio
           porque el paso "abrir el siguiente" solo se dispara como efecto
           inmediato de cerrar dentro de la MISMA corrida), abre el
           siguiente PENDIENTE por orden_secuencia.

           Version anterior (incorrecta, descartada): exigia solo que
           existiera ALGUNA medicion VIGENTE en topografia_avance, sin
           mirar la fecha. Se comprobo en la rotopala 2 / campaña 8 que
           eso abre el modulo equivocado: los modulos 103 a 123 llevaban
           meses (abril a julio) ya extraidos casi al 100 % por camiones,
           congelados en bloque el 2026-07-29 sin nunca pasar por
           secuencia, y el 123 en particular tenia 4 mediciones VIGENTE
           pero todas de 2026-07-01 a 2026-07-04 -- anteriores incluso al
           124 (que midio hasta el 07-08). Al ordenar por orden_secuencia,
           que sp_definir_secuencia asigna por modulo_numero ascendente,
           123 quedaba antes que 125 y se abria primero aunque su ultima
           actividad real fuera mas vieja que la del propio modulo que se
           acababa de cerrar.

           Fix: la evidencia ahora exige que la medicion VIGENTE sea
           POSTERIOR a la ultima medicion real de los modulos ya CERRADOS
           de esa misma rotopala/campaña (mismo principio de "solo cola"
           que v_preliminar_cv25 y AVANCE_DE_SECUENCIA). Con esto, 123
           queda descartado (su ultima medicion, 07-04, es anterior al
           07-08 del 124) y el candidato correcto pasa a ser 125 (mide
           desde el 07-09, despues del 124).
        ------------------------------------------------------------- */
        DECLARE @RotRell tinyint, @CampRell int;
        DECLARE @SecRell int, @ModRell int, @PadRell int, @ModNumRell int;
        DECLARE @UltimaMedicionCerrado date;

        DECLARE grupos_relleno CURSOR LOCAL FAST_FORWARD FOR
            SELECT DISTINCT s.rotopala_id, s.[campaña_id]
            FROM [reclamo].[secuencia_rotopala] s
            WHERE NOT EXISTS
            (
                SELECT 1 FROM [reclamo].[secuencia_rotopala] s2
                WHERE s2.rotopala_id = s.rotopala_id AND s2.[campaña_id] = s.[campaña_id]
                  AND s2.estado = 'ABIERTO'
            )
            AND EXISTS
            (
                SELECT 1 FROM [reclamo].[secuencia_rotopala] s3
                WHERE s3.rotopala_id = s.rotopala_id AND s3.[campaña_id] = s.[campaña_id]
                  AND s3.estado = 'CERRADO'
            );
        OPEN grupos_relleno;
        FETCH NEXT FROM grupos_relleno INTO @RotRell, @CampRell;
        WHILE @@FETCH_STATUS = 0
        BEGIN
            SET @SecRell = NULL;

            SET @UltimaMedicionCerrado =
            (
                SELECT MAX(t.fecha_medicion)
                FROM [reclamo].[secuencia_rotopala] s4
                INNER JOIN [reclamo].[topografia_avance] t
                        ON t.modulo_id = s4.modulo_id AND t.estado = 'VIGENTE'
                WHERE s4.rotopala_id = @RotRell AND s4.[campaña_id] = @CampRell
                  AND s4.estado = 'CERRADO'
            );

            SELECT TOP (1)
                @SecRell = s.secuencia_id, @ModRell = s.modulo_id,
                @PadRell = s.pad_id, @ModNumRell = s.modulo_numero
            FROM [reclamo].[secuencia_rotopala] s
            WHERE s.rotopala_id = @RotRell AND s.[campaña_id] = @CampRell
              AND s.estado = 'PENDIENTE'
              AND EXISTS
              (
                  SELECT 1 FROM [reclamo].[topografia_avance] t
                  WHERE t.modulo_id = s.modulo_id AND t.estado = 'VIGENTE'
                    AND
                    (
                        @UltimaMedicionCerrado IS NULL
                        OR t.fecha_medicion > @UltimaMedicionCerrado
                    )
              )
            ORDER BY s.orden_secuencia ASC;

            IF @SecRell IS NOT NULL
            BEGIN
                UPDATE [reclamo].[secuencia_rotopala]
                SET estado = 'ABIERTO', fecha_apertura = CAST(SYSDATETIME() AS date)
                WHERE secuencia_id = @SecRell;

                INSERT INTO [reclamo].[log_automatizacion]
                    (ejecucion_id, accion, pad_id, [campaña_id], modulo_id, modulo_numero, detalle)
                VALUES
                    (@EjecucionId, 'ABIERTO_AUTOMATICO', @PadRell, @CampRell, @ModRell, @ModNumRell,
                     N'Rotopala sin modulo ABIERTO tras el backfill de secuencia. Se abre el '
                        + N'siguiente PENDIENTE con medicion real de topografia POSTERIOR a la '
                        + N'ultima medicion de los modulos ya cerrados (evidencia fisica de '
                        + N'actividad reciente, no se abre solo por haber cupo ni por tener '
                        + N'cualquier medicion historica).');
            END;

            FETCH NEXT FROM grupos_relleno INTO @RotRell, @CampRell;
        END;
        CLOSE grupos_relleno;
        DEALLOCATE grupos_relleno;

        DECLARE @Congelados int, @Abiertos int, @Cerrados int, @Alertas int;
        SELECT
            @Congelados = SUM(CASE WHEN accion = 'CONGELADO_AUTOMATICO' THEN 1 ELSE 0 END),
            @Abiertos   = SUM(CASE WHEN accion = 'ABIERTO_AUTOMATICO'   THEN 1 ELSE 0 END),
            @Cerrados   = SUM(CASE WHEN accion = 'CERRADO_AUTOMATICO'   THEN 1 ELSE 0 END),
            @Alertas    = SUM(CASE WHEN accion LIKE 'ALERTA%'           THEN 1 ELSE 0 END)
        FROM [reclamo].[log_automatizacion]
        WHERE ejecucion_id = @EjecucionId;

        PRINT 'Congelados automaticamente : ' + CAST(COALESCE(@Congelados,0) AS varchar);
        PRINT 'Abiertos automaticamente   : ' + CAST(COALESCE(@Abiertos,0) AS varchar);
        PRINT 'Cerrados automaticamente   : ' + CAST(COALESCE(@Cerrados,0) AS varchar);
        PRINT 'Alertas para revisar       : ' + CAST(COALESCE(@Alertas,0) AS varchar);

        UPDATE [reclamo].[log_ejecucion]
        SET fecha_fin       = SYSDATETIME(),
            filas_afectadas = COALESCE(@Congelados,0) + COALESCE(@Abiertos,0) + COALESCE(@Cerrados,0),
            estado          = 'OK'
        WHERE ejecucion_id = @EjecucionId;

        SELECT
            l.log_id, l.accion, l.pad_id, l.[campaña_id], l.modulo_id, l.modulo_numero,
            l.detalle, l.fecha_evento
        FROM [reclamo].[log_automatizacion] l
        WHERE l.ejecucion_id = @EjecucionId
        ORDER BY CASE WHEN l.accion LIKE 'ALERTA%' THEN 0 ELSE 1 END, l.log_id;
    END TRY
    BEGIN CATCH
        UPDATE [reclamo].[log_ejecucion]
        SET fecha_fin = SYSDATETIME(), estado = 'ERROR', mensaje = ERROR_MESSAGE()
        WHERE ejecucion_id = @EjecucionId;
        THROW;
    END CATCH
END;